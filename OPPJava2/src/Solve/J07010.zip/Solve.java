package Solve;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.util.TreeSet;

public class Solve{ 
    public static void main(String[] args) throws FileNotFoundException {
        Scanner sc = new Scanner(new File("C:\\Users\\NITRO\\PJ4\\OPPJava2\\src\\Solve\\SV.in"));
        ArrayList<J07010> list = new ArrayList<>();
        int t = Integer.parseInt(sc.nextLine());
        while(t-- >0){
            System.out.println(new J07010(sc.nextLine(),sc.nextLine(), sc.nextLine(), Double.parseDouble(sc.nextLine())));
        }
    }
}