package Solve;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.util.TreeSet;

public class Solve{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        ArrayList<J04013> list = new ArrayList<>();
        list.add(new J04013(sc.nextLine(),sc.nextLine(),Double.parseDouble(sc.nextLine()),Double.parseDouble(sc.nextLine()),Double.parseDouble(sc.nextLine())));
        for(J04013 x:list) System.out.println(x);
    }
}